from django.db import models
from users.models import User, UserProfile
from homeworks.models import (
	Grade,
	Subject,
	Book,
	Homework,
	HomeworkImage)

# Create your models here.

