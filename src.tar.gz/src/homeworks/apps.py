from django.apps import AppConfig


class HomeworksConfig(AppConfig):
    name = 'homeworks'
